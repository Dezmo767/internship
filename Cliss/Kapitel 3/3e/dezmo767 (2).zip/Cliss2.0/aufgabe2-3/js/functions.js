function isInt(eingabe){
  return eingabe.trim() !== "" && parseInt(eingabe) === parseFloat(eingabe);
}
