function substring(eingabe, start, end){
  return eingabe.substring(start, end);
}

function lettersOnly(eingabe){
  var regex = /^[A-Za-z]+$/;
  return eingabe.match(regex) != null;

}

function digitsOnly(eingabe){
  var regex = /^[0-9]+$/;
  return eingabe.match(regex) != null;
}

function containsUppercaseLetter(eingabe){
  var regex = /[A-Z]/;
  return eingabe.match(regex) != null;
}

function containsLowercaseLetter(eingabe){
  var regex = /[A-Z]/;
  return eingabe.match(regex) != null;
}

function containsDigit(eingabe){
  var regex = /[0-9]/;
  return eingabe.match(regex) != null;
}


function containsSpecialCharacter(eingabe){
  var regex = /[&*+_-]/;
  return eingabe.match(regex) != null;
}

function length(eingabe){
  return eingabe.length;
}
